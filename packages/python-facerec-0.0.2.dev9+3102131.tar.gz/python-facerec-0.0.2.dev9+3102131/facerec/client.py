#!/usr/bin/python
# -*- coding: UTF-8 -*-
# created: 30.04.2018
# author:  TOS

import requests
import base64
import json
from io import BytesIO

class FacerecApi(object):

    def __init__(self, url='http://localhost:80'):
        self.url = url

    def faces(self):
        return requests.get(self.url+'/faces').json()

    def identify_facecode(self, code):
        # encode face code and send to identify
        payload = {'code': base64.b64encode(code.tobytes()).decode('ascii')}
        r = requests.post('facecode/identify', data=json.dumps(payload), content_type='application/json')
        return r.json()

    def identify_image(self, image):
        image = image.convert('RGB')
        buffer = BytesIO()
        image.save(buffer, format="JPEG")
        # encode face code and send to identify
        payload = {'image': base64.b64encode(buffer.getvalue()).decode('ascii')}
        r = requests.post('image/identify', data=json.dumps(payload), content_type='application/json')
        return r.json()